package com.cognizant.exception;

public class HomeLoanEligibility extends RuntimeException {
	public HomeLoanEligibility(String s) {
		super(s);
	}
}
