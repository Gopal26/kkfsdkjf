package test.java;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cognizant.entity.TransactionDetails;
import com.cognizant.entity.UserDetails;
import com.cognizant.exception.InvalidAccountBalance;
import com.cognizant.service.PerformTransactionService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:beans.xml")
public class TestPerformTransaction {

	@Autowired
	PerformTransactionService service;
	TransactionDetails transaction;

	@Before
	public void setUp() {
		//transaction = new TransactionDetails("nhpjk", "DEPOSIT", 150001);
	}

	//@Test
	public void testUpdateTransactionDetails() {
		transaction = new TransactionDetails("nhpjk", "DEPOSIT", 150001);
		System.out.println(transaction);
		service.updateTransactionDetails(transaction, 1234567890123546L);
		assertTrue(true);
	}

	// @Test
	public void retrieveTransactionDetails() {
		List<TransactionDetails> transactionDetails = service.retrieveTransactionDetails((long) 12345);
		assertEquals(transactionDetails.size(), 2);

	}
	
	@Test
	public void insufficientBalance() {
		
		UserDetails user=new UserDetails(1234567890123546l,"SAVINGS","Aman",4831763);
		System.out.println(transaction);
		
		try {
			service.updateUser(8450000,user,"WITHDRAWAL");
			Assert.fail("Saving Account's Balance can't be less than 5000");
		} catch (InvalidAccountBalance e) {
			// TODO Auto-generated catch block
			e.getMessage();
			
		}
		
	}


}
